const express = require('express') 
// express 기능 가져와서 상수에 할당.. 
// 여기서 express는 서버를 구축할 수 있게 만드는 웹 애플리케이션 프레임워크..  express.내용 정리..
// 따로 설치가 요구됨.. 터미널 cmd npm install express.. 
const app = express()  
const PORT = process.env.PORT || 4000;
// 서버 포트 4000번.. 여기서 4000 은 유저가 직접 정한 것으로 기존에 사용하는 것들과 충돌만 일어나지 않으면 문제x
// ex 8080port.. etc

movie_list = [
    {id:1,title: 'perl harbor'},
    {id:2,title: 'lord of the rings'},
    {id:3,title: 'top gun'},
]

// 위는 setting 아래는 요청..  

app.get('/',(req,res)=>{
    res.send('root response')
    // get방식 요청,응답.. 화살표 함수..
})
//express 서버가 get방식 요청을 받아들인다. 

app.get('/hello',(req,res)=>{
    res.send('hello response')
    // get방식 요청,응답.. 화살표 함수..
})

app.get('/movies:id',(req,res)=>{
    console.log(req.params)
    console.log(req.params.id)
    for(var i = 0; i < movie_list.length; i++){
        if(id == movie_list[i].id){
            console.log('id: '+movie_list[i].id)
            console.log('title: '+movie_list[i].title)
        }
    }
})

app.get('/post/movies:id&:title',(req,res)=>{
    for(var i = 0; i < movie_list.length; i++){
        if(id == movie_list[i].id){
            console.log('id: '+movie_list[i].id)
            console.log('title: '+movie_list[i].title)
        }
    }
})

app.get('/bye',(req,res)=>{
    res.send('bye response')
    // get방식 요청,응답.. 화살표 함수..
})

app.get('/api/person1/:name',(req,res)=>{ // name값도 넘김..  name값에 담긴 데이터를 받을 때 이런 식으로 작성..  get, post방식...?? 
    console.log(req.params)
    console.log(req.params.name)
    // request parameters(인수, 인자) name
    const name1 = req.params.name
    res.send('person1 response:'+name1) // 관련 데이터를 주는 것이 아닌 값을 받았다는 확인만 출력.. 
    // get방식 요청,응답.. 화살표 함수..
})

app.get('/api/person2/:name&:age',(req,res)=>{ // name값,age값도 넘김..  복수 개로 작성할 때 &로 연결.. 값을 작성할 때는 무조건 앞에 콜론(:)을 붙여줘야 함 아니면 일반 문자 취급함.. 
    console.log(req.params)         // get에서 요청한 name, age와 parameter값이 일치하지 않으면 undefined로 출력됨.. 
    console.log(req.params.name)
    console.log(req.params.age)
    const name2 = req.params.name
    const age = req.params.age
    // request parameters(인수, 인자) name
    res.send('person2 response: '+name2+'<br>'+'person2 response: '+age) // 관련 데이터를 주는 것이 아닌 값을 받았다는 확인만 출력.. 
    // get방식 요청,응답.. 화살표 함수..
})

app.get('/api/add/:num1&:num2',(req,res)=>{
    console.log(req.params)
    console.log(req.params.num1)
    console.log(req.params.num2)
    const num1 = parseInt(req.params.num1)
    const num2 = parseInt(req.params.num2)
    res.send(`${num1} + ${num2} = ${num1 + num2}`)
})

app.get('/api/sub/:num1&:num2',(req,res)=>{
    console.log(req.params)
    console.log(req.params.num1)
    console.log(req.params.num2)
    const num1 = parseInt(req.params.num1)
    const num2 = parseInt(req.params.num2)
    res.send(`${num1} - ${num2} = ${num1 - num2}`)
})

app.get('/api/multi/:num1&:num2',(req,res)=>{
    console.log(req.params)
    console.log(req.params.num1)
    console.log(req.params.num2)
    const num1 = parseInt(req.params.num1)
    const num2 = parseInt(req.params.num2)
    res.send(`${num1} * ${num2} = ${num1 * num2}`)
})

app.get('/api/div/:num1&:num2',(req,res)=>{
    console.log(req.params)
    console.log(req.params.num1)
    console.log(req.params.num2)
    const num1 = parseInt(req.params.num1)
    const num2 = parseInt(req.params.num2)
    res.send(`${num1} / ${num2} = ${num1 / num2}`)
})

app.listen(PORT,()=>{
    console.log(`Server On: http://localhost:${PORT}`) // localhost - 내컴퓨터 의미.. 127.0.0.1 IP
                                                        // http://localhost:4000/hello 요청 서버에 전달.. 서버에 get방식 hello 요청 .. 
    // template string 
})

// nodeJS가 바다라면 express는 그 바다에 서식하는 종 중 하나라고 생각하면됨.. express는 모듈 웹프레임워크 라고도 함.. 
// http: hyper text transfer protocol
// nodejs를 기반으로 express웹프레임워크를 이용해 rest-api서버 구축... 지금 예제로 한걸 표현한면 이렇다. 