const express = require('express');
const app = express();
const PORT = process.env.PORT || 4000;
const db = require('./config/db.js')

app.get('/hello',(req,res)=>{
    console.log('/hello')
})

app.get('/player_info',(req,res)=>{
    console.log('/player_info')
    db.query("select * from player_info",(err,data)=>{
        if(!err){
            console.log(data)
        }else{
            console.log(err)
        }
    })
})

app.get('/player_info/:name',(req,res)=>{
    const name=req.params.name
    console.log('/player_info/:name')
    console.log(name)
    db.query(`select * from player_info where name='${name}'`,(err,data)=>{
        if(!err){
            console.log(data)
        }else{
            console.log(err)
        }
    })
})

app.get('/player_info/insert/:name&:team&:win&:lose&:point',(req,res)=>{
    const name=req.params.name
    const team=req.params.team
    const win=req.params.win
    const lose=req.params.lose
    const point=req.params.point
    console.log('/player_info/insert/:name&:team&:win&:lose&:point')
    console.log(name)//신희범
    console.log(team)//AlphaX
    console.log(win)//3
    console.log(lose)//5
    console.log(point)//-2
    db.query(`insert into player_info(name,team,win,lose,point) values('${name}','${team}',${win},${lose},${point})`,(err,data)=>{
        if(!err){
            console.log(data)
        }else{
            console.log(err)
        }
    })
})

app.get('/player_info/update/:name&:point&:win&:lose',(req,res)=>{
    const name=req.params.name
    const point=req.params.point
    const win=req.params.win
    const lose=req.params.lose
    console.log('/player_info/update/:name&:point')
    console.log(name)//player name
    console.log(point)// win - lose
    db.query(`update player_info set win=${win}, lose=${lose}, point=${point} where name='${name}'`,(err,data)=>{
        if(!err){// set 부분에서 여러개 항목을 새로 설정하려면 쉼표로 구분!!!
            console.log(data)
        }else{
            console.log(err)
        }
    })
})

app.get('/player_info/update2/:listNum&:name',(req,res)=>{
    const listNum = req.params.listNum //table에서 따로 정의되지 않은 부분도 값으로 넣을 수 있음.. 
    const name = req.params.name
    const list = [
        {name:'김동원',team:'GP',win:2,lose:6,point:-4},
        {name:'장현우',team:'Team_NV',win:1,lose:7,point:-6},
        {name:'최민우',team:'GP',win:0,lose:8,point:-8}
    ]
    console.log('/player_info/update/:listNum')
    console.log(listNum)// win - lose
    db.query(`update player_info set name='${list[listNum].name}', team='${list[listNum].team}',  win=${list[listNum].win}, lose=${list[listNum].lose}, point=${list[listNum].point} where name='${name}'`,(err,data)=>{
        if(!err){// set 부분에서 여러개 항목을 새로 설정하려면 쉼표로 구분!!!
            console.log(data)
        }else{
            console.log(err)
        }
    })
})

app.get('/player_info/auto/insert2/',(req,res)=>{
    const list = [
        {name:'신희범',team:'GP',win:3,lose:5,point:-2},
        {name:'장현우',team:'Team_NV',win:1,lose:7,point:-6},
        {name:'최민우',team:'GP',win:0,lose:8,point:-8}
    ]
    console.log('/player_info/auto/insert2')
    for(var i =0; i < list.length; i++){
        db.query(`insert into player_info(name,team,win,lose,point) values(name='${list[i].name}', team='${list[i].team}',  win=${list[i].win}, lose=${list[i].lose} , point=${list[i].point}) `,(err,data)=>{
            if(!err){// set 부분에서 여러개 항목을 새로 설정하려면 쉼표로 구분!!!
                console.log(data)
            }else{
                console.log(err)
            }
        })
    }
})

app.get('/player_info/delete/:name',(req,res)=>{
    const name=req.params.name
    console.log('/player_info/delete/:name')
    console.log(name)//신희범
    db.query(`delete from player_info where name='${name}'`,(err,data)=>{
        if(!err){
            console.log(data)
        }else{
            console.log(err)
        }
    })
})

app.get('/player_info/order/desc',(req,res)=>{// 위쪽 이름 조회하는 요청이랑 겹침.. ex 경로 끝에 desc를 쓰면 그걸 name값으로 인식해버림.. 해결법은 중간에 경로를 하나 임의로 추가!!
    console.log('/player_info/desc')
    db.query(`select * from player_info order by point desc`,(err,data)=>{
        if(!err){
            console.log(data)
        }else{
            console.log(err)
        }
    })
})

app.listen(PORT, () => {
    console.log(`Server On : http://localhost:${PORT}/`);
})