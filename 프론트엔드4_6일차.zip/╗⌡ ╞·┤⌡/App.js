
import './App.css';
import Car from './components/Car';
import Movie from './components/Movie';
//현재 경로의 components 폴더에 있는 Person.js 파일을 
//Person 컴포넌트를 가져온다. 
function App() { /*실제로는 jsx로 스크립트의 확장언어.. html태그를 스크립트 내에서 다루기 위해 사용..  */


  //return은 그냥 화면 
  return (
    <div id="App">
      <Car name='BMW' produce='HyunDae' price='4450'></Car>
      <Car name='NewEleCar' produce='Tessla' price='7000'></Car>
      <Car name='SamsungNewCar' produce='Samsung' price='3200'></Car>
      <Movie name='범죄도시2' main='이상용' star='4.5'></Movie>
      <Movie name='한산: 용의 출현' main='김한민' star='4.2'></Movie>
      <Movie name='토르: 러브 앤 썬더' main='타이카 와이티티' star='4.7'></Movie>
    </div>
  );
}
/*
react port 3000 UI 전달
node port 4000 정보처리
sql port 3306 데이터 관리

컴포넌트: 화면+기능 단위...  요소라고 생각하면 됨. 
하단의 export가 화면으로 송출시키는 것!
 */
export default App;
