
import './App.css';
import Person from './components/Person';
import Car from './components/Car';
import Movie from './components/Movie';
import {Component} from 'react';
//현재 경로의 components 폴더에 있는 Person.js 파일을 
//Person 컴포넌트를 가져온다. 
class App extends Component{ // extned-확장.. class 상속 관련 문법.. App클래스가Component 클래스에게 상속 받는다.(기능 부여)
  constructor(props){ // 객체가 생성될 때 호출.. 생성자.. 
    super(props);
    this.state={
      name:'이민호',
      age:20,
      height:176.6,
      model:'소나타',
      provider:'현대',
      price:2300
    }                  // 클래스가 메모리에 로드된게 (실체화된것..)
  }

  render(){                 // App 클래스는 Component 클래스를 이용해서 확장한다.
    return(                //App는 자식 클래스 Component는 부모 클래스 App가 클래스형 컴포넌트가 될수있게 해주는게 Component클래스다.      
      <div id="App">
        <Person name={this.state.name} age={this.state.age} height={this.state.height}></Person>
        <Car model={this.state.model} provider={this.state.provider} price={this.state.price}></Car>
      </div>
    )
  }
}
/*
react port 3000 UI 전달
node port 4000 정보처리
sql port 3306 데이터 관리

컴포넌트: 화면+기능 단위...  요소라고 생각하면 됨. 
하단의 export가 화면으로 송출시키는 것!
 */
export default App;
