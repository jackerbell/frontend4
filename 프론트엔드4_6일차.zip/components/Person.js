/*컴포넌트 작명시 앞은 무조건 대문자 처리 */
import '../components/css/Person.css';

function Person(props) { /*실제로는 jsx로 스크립트의 확장언어.. html태그를 스크립트 내에서 다루기 위해 사용..  */
  return (
    <div id="Person">
      <div>
        이름:{props.name}
      </div>
      <div>
        나이:{props.age}
      </div>
      <div>
        키:{props.height}
      </div>
    </div>
  );
}
/*
react port 3000 UI 전달
node port 4000 정보처리
sql port 3306 데이터 관리

컴포넌트: 화면+기능 단위...  요소라고 생각하면 됨. 
 */
export default Person;
