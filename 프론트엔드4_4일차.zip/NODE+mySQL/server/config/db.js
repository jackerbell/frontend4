var mysql=require('mysql')
const db = mysql.createPool({
    host:'localhost',//hosting 장소.. 
    user:'root', //user 정의.. 
    password:'1234',
    database:'node_db', //sql에 생성되어 있는 node_db라는 데이터베이스
    port:3306//(default 값일 경우 따로 설정해줄 필요 없음..)
})

module.exports=db;// db모듈을 외부로 보냄.. 