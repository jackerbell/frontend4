const express = require('express');
const app = express();
const PORT = process.env.PORT || 4000;
const db = require('./config/db.js') //호출한 db를 사용하기 위해서 주소입력

app.get('/hello',(req,res)=>{
    console.log('/hello')
})

app.get('/person',(req,res)=>{
    console.log('/person') //person테이블에서 가져옴.. 
    db.query('select * from person',(err,data)=>{ //foreach문 참조.. 
        if(!err){                               //sql에서 썼던 명령문 넣어서 실행.. 
            console.log(data);
        }else console.log(err);
    })
})

app.get('/person/:name',(req,res)=>{
    const name = req.params.name
    console.log('/person/:name')
    console.log(name)
    db.query(`select * from person where name='${name}'`,(err,data)=>{ //foreach문 참조.. 
        if(!err){                               //sql에서 썼던 명령문 넣어서 실행.. 
            console.log(data);                 //${}에 대해선 따옴표 없이 글자만 입력!!
        }else console.log(err);
    })
    //db.query('select * from where name=')
})

app.get('/person/insert/:emp_no&:name&:salary',(req,res)=>{ //원래 추가하려면 post방식을 기용해야함.. 
    const name = req.params.name
    const emp_no =req.params.emp_no
    const salary = req.params.salary
    console.log('/person/insert')
    console.log(name)
    db.query(`insert into person(emp_no,name,salary) values(${emp_no},'${name}',${salary})`,(err,data)=>{ //foreach문 참조.. 문자열 항목에 대해서는 따옴표 붙여주기!!
        if(!err){                               //sql에서 썼던 명령문 넣어서 실행.. 
            console.log(data);                 //${}에 대해선 따옴표 없이 글자만 입력!!
        }else console.log(err);
    })
    //db.query('select * from where name=')
})


app.get('/person/update/:emp_no&:name',(req,res)=>{ //원래 추가하려면 post방식을 기용해야함.. 
    const name = req.params.name
    const emp_no =req.params.emp_no
    const salary = req.params.salary
    console.log('/person/insert/:emp_no&:name')
    console.log(name)
    db.query(`update set emp_no=${emp_no} where name='${name}'`,(err,data)=>{ //foreach문 참조.. 문자열 항목에 대해서는 따옴표 붙여주기!!
        if(!err){                               //sql에서 썼던 명령문 넣어서 실행.. 
            console.log(data);                 //${}에 대해선 따옴표 없이 글자만 입력!!
        }else console.log(err);
    })
    //db.query('select * from where name=')
})

app.get('/person/delete/:name',(req,res)=>{ //원래 추가하려면 post방식을 기용해야함.. 
    const name = req.params.name
    console.log('/person/delete/:emp_no&:name')
    console.log(name)
    db.query(`delete from person where name='${name}'`,(err,data)=>{ //foreach문 참조.. 문자열 항목에 대해서는 따옴표 붙여주기!!
        if(!err){                               //sql에서 썼던 명령문 넣어서 실행.. 
            console.log(data);                 //${}에 대해선 따옴표 없이 글자만 입력!!
        }else console.log(err);
    })
    //db.query('select * from where name=')
})


app.listen(PORT, () => {
    console.log(`Server On : http://localhost:${PORT}/`);
})