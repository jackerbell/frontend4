const express = require('express')
const app = express()
const PORT = process.env.PORT || 4000;



app.get('/',(req,res)=>{
    res.send('root response')
})
app.get('/add/:num1&:num2',(req,res)=>{
    console.log(req.params)
    console.log(req.params.num1)
    console.log(req.params.num2)
    const num1=parseInt(req.params.num1)//정수 형변환
    const num2=parseInt(req.params.num2)
    const result=num1+num2
    res.send('add result:'+result)
})
app.listen(PORT,()=>{
    console.log(`Server On: http://localhost:${PORT}`)
    //template string
    //console.log('Server On: http://localhost:'+PORT)
    //'' ``
})

