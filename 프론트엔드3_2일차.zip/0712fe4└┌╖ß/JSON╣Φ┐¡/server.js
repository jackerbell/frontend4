const express = require('express')
const app = express()
const PORT = process.env.PORT || 4000;

movie_list=[
    {id:1,title:'perl harbor'},
    {id:2,title:'lord of the rings'},
    {id:3,title:'top gun'}
]//JSON배열

student_list = [
    {sn:20130279,sub :'electronic',name:Jason},
    {sn:20140279,sub :'art',name:Dason},
    {sn:20150279,sub :'math_science',name:Cason},
]
app.get('/',(req,res)=>{
    res.send('root response')
})
app.get('/movies',(req,res)=>{
    for(var i=0; i<movie_list.length; i++){
        console.log('id:'+movie_list[i].id)
        console.log('title:'+movie_list[i].title)
    }
})
app.get('/movies:id',(req,res)=>{
    const id=req.params.id
    for(var i=0; i<movie_list.length; i++){
        if(id==movie_list[i].id){
            console.log('id:'+movie_list[i].id)
            console.log('title:'+movie_list[i].title)
        }
    }
    res.send('/movies/:id response')
})

app.get('/put/movies:id&:title',(req,res)=>{
    const id=req.params.id
    const title=req.params.title
    //특정 id의 제목을 title로 변경
    //for - if , movielist
    var movie_obj = {id:id,title:title}
    movie_list
    for(var i =0; i<movie_list.length; i++){
        console.log('id:'+movie_list[i].id)
        console.log('title:'+movie_list[i].title)
        if(i==2){
            
        }
    }
    for(var i=0; i<movie_list.length; i++){
        if(id==movie_list[i].id){
            console.log('id:'+movie_list[i].id)
            console.log('title:'+movie_list[i].title)
        }
    }

})

app.get('/delete/movies:id',(req,res)=>{ // id만 입력에 해당.. 
    const id=req.params.id
    const title=req.params.title
    //splice
    //배열의 특정원소를 삭제.. 
  // 
     
        movie_list.splice(id-1,1)
       
        for(var i = 0; i< movie_list.length; i ++){
            console.log('id:'+movie_list[i].id)
            console.log('title:'+movie_list[i].title)
        }


    res.send('/delete/movies/:id')
  
})

app.get('/lookup/students:sn&:sub&:name',(req,res)=>{ // id만 입력에 해당.. 
    const id=req.params.sn
    const sub=req.params.sub
    const name = req.params.name
    for(var i = 0; i < student_list.length; i++){
        console.log(`sn:${student_list[i].sn}`+'<br>')
        console.log(`sub:${student_list[i].sub}`+'<br>')
        console.log(`name:${student_list[i].name}`+'<br>')
    }
    res.send('/lookup/students/:sn&:sub:&name response')
})

app.get('/delete/students:sn&:sub&:name',(req,res)=>{ // id만 입력에 해당.. 
    const id=req.params.sn
    const sub=req.params.sub
    const name = req.params.name
    student_list.slice(sn-1,1)
    for(var i = 0; i < student_list.length; i++){
        console.log(`sn:${student_list[i].sn}`+'<br>')
        console.log(`sub:${student_list[i].sub}`+'<br>')
        console.log(`name:${student_list[i].name}`+'<br>')
    }
    res.send('/delete/students/:sn&:sub:&name response')
})

app.get('/generate/students:sn&:sub&:name',(req,res)=>{ // id만 입력에 해당.. 
    const id=req.params.sn
    const sub=req.params.sub
    const name = req.params.name
    for(var i = 0; i < student_list.length; i++){
        console.log(`sn:${student_list[i].sn}`+'<br>')
        console.log(`sub:${student_list[i].sub}`+'<br>')
        console.log(`name:${student_list[i].name}`+'<br>')
    }
    res.send('/generate/students/:sn&:sub:&name response')
})

app.get('/push/students:sn&:sub&:name',(req,res)=>{ // id만 입력에 해당.. 
    const id=req.params.sn
    const sub=req.params.sub
    const name = req.params.name
    var student_obj = {sn:20170279,sub:'manage',name:'demian'}
    student_list.push(student_obj)
    for(var i = 0; i < student_list.length; i++){
        console.log(`sn:${student_list[i].sn}`+'<br>')
        console.log(`sub:${student_list[i].sub}`+'<br>')
        console.log(`name:${student_list[i].name}`+'<br>')
    }
    res.send('/push/students/:sn&:sub:&name response')
})


app.listen(PORT,()=>{
    console.log(`Server On: http://localhost:${PORT}`)
    //template string
    //console.log('Server On: http://localhost:'+PORT)
    //'' ``

})
/*
app.get('/post/movies:id&:title',(req,res)=>{ // post 
    const id=req.params.id
    const title=req.params.title
    var movie_obj = {id:id,title:title}
    //movie_list.push(movie_obj) 해당 부분은 잘됨.. 
    movie_list=movie_list.concat(movie_obj) // concat은 추가된 배열에 리턴되기 때문에 왼쪽에서 받아야 된다. 
    for(var i=0; i<movie_list.length; i++){
        
    }
    res.send('/post/movie:id&:title')
    //push,concat같은 배열 추가하는 메서드 써서...
    // push는 넣어주는 거 한 번으로 끝..
    // concat은 리턴값을 배열에 다시 저장해야된다. 
    //JSON배열의 마지막 항목에 추가되도록...
})*/