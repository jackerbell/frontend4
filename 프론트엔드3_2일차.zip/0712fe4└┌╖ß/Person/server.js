const express = require('express')//기능 가져와서
//웹 애플리케이션 프레임워크
const app = express() //express객체 생성
const PORT = process.env.PORT || 4000;
//서버 포트를 4000번...
//내가 정한건데...기존의 well known 포트를 피해가면된다.

            //request, response
app.get('/',(req,res)=>{
            //화살표 함수 (arrow function)
    res.send('root response')
})
//express서버가 get방식 요청을 받아들인다.
app.get('/hello',(req,res)=>{
    res.send('hello response')
})

app.get('/bye',(req,res)=>{
    res.send('bye response')
})

app.get('/api/person1/:name',(req,res)=>{
    console.log(req.params)
    console.log(req.params.name)
    const name=req.params.name
    //request(요청) parameters(인수,인자) name
    res.send('person1 response:'+name)
})
app.get('/api/person2/:name&:age',(req,res)=>{
    console.log(req.params)
    console.log(req.params.name)
    console.log(req.params.age)
    res.send('person2 response')
})

app.listen(PORT,()=>{
    console.log(`Server On: http://localhost:${PORT}`)
    //template string
    //console.log('Server On: http://localhost:'+PORT)
    //'' ``
})

